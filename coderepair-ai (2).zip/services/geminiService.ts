import { GoogleGenAI, Type } from "@google/genai";
import { FixedCodeResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fixCode = async (brokenCode: string, languageHint?: string): Promise<FixedCodeResponse> => {
  const modelId = "gemini-2.5-flash"; // Fast and efficient for code tasks

  const systemInstruction = `
    You are an expert Senior Software Engineer and Code Auditor. 
    Your task is to analyze the provided code snippet, identify any syntax errors, logical bugs, runtime issues, or best practice violations.
    
    You must:
    1. Detect the programming language if not specified.
    2. Fix the code to be fully functional and optimized.
    3. Provide a clear, concise explanation of what was wrong and how you fixed it.
    4. Summarize the main error in one sentence.
    
    Return the result in a structured JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `Please fix this code:\n\n${brokenCode}\n\n${languageHint ? `Context: User thinks this is ${languageHint}` : ''}`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fixedCode: {
              type: Type.STRING,
              description: "The complete, corrected version of the code.",
            },
            explanation: {
              type: Type.STRING,
              description: "A detailed explanation of the fixes applied.",
            },
            detectedLanguage: {
              type: Type.STRING,
              description: "The programming language detected (e.g., Python, JavaScript).",
            },
            errorSummary: {
              type: Type.STRING,
              description: "A very short summary of the primary error found.",
            }
          },
          required: ["fixedCode", "explanation", "detectedLanguage", "errorSummary"],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from Gemini.");
    }

    return JSON.parse(text) as FixedCodeResponse;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to fix code. Please check your input and try again.");
  }
};