export interface FixedCodeResponse {
  fixedCode: string;
  explanation: string;
  detectedLanguage: string;
  errorSummary: string;
}

export interface EditorState {
  code: string;
  language: string;
}

export enum AppStatus {
  IDLE = 'IDLE',
  FIXING = 'FIXING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}