import React, { useRef, useEffect } from 'react';

interface CodeBlockProps {
  value: string;
  onChange?: (value: string) => void;
  readOnly?: boolean;
  label: string;
  placeholder?: string;
  language?: string;
  isTyping?: boolean;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({
  value,
  onChange,
  readOnly = false,
  label,
  placeholder,
  language = 'plaintext',
  isTyping = false
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  const lineCount = value.split('\n').length;
  const lines = Array.from({ length: Math.max(lineCount, 15) }, (_, i) => i + 1);

  const handleScroll = () => {
    if (textareaRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  // Typing effect simulation for readOnly blocks that are "streaming"
  useEffect(() => {
    if (isTyping && textareaRef.current) {
      textareaRef.current.scrollTop = textareaRef.current.scrollHeight;
    }
  }, [value, isTyping]);

  return (
    <div className={`flex flex-col h-full rounded-xl overflow-hidden border transition-all duration-300 shadow-2xl
      ${readOnly 
        ? 'bg-[#0F111A]/80 border-indigo-500/30 shadow-indigo-900/10' 
        : 'bg-[#0F111A]/80 border-white/10 focus-within:border-indigo-500/50 focus-within:shadow-indigo-500/10'
      }`}>
      
      {/* IDE Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#0A0C14] border-b border-white/5">
        <div className="flex items-center gap-3">
          {/* Window Controls */}
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
          </div>
          <span className="ml-2 text-xs font-medium text-slate-400 flex items-center gap-2">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            {label}
          </span>
        </div>
        <div className="flex items-center gap-2">
           <div className="px-2 py-1 rounded text-[10px] font-mono uppercase tracking-wider text-indigo-300 bg-indigo-500/10 border border-indigo-500/20">
             {language}
           </div>
        </div>
      </div>

      {/* Editor Body */}
      <div className="relative flex-1 flex group">
        
        {/* Line Numbers */}
        <div 
          ref={lineNumbersRef}
          className="hidden sm:flex flex-col items-end py-4 pl-2 pr-4 bg-[#0A0C14]/50 text-slate-600 font-mono text-xs leading-relaxed select-none overflow-hidden w-12 border-r border-white/5"
        >
          {lines.map((line) => (
            <div key={line} className="h-6 flex items-center">{line}</div>
          ))}
        </div>

        {/* Text Area */}
        <div className="relative flex-1">
           <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange && onChange(e.target.value)}
            onScroll={handleScroll}
            readOnly={readOnly}
            placeholder={placeholder}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            className={`w-full h-full p-4 bg-transparent font-mono text-sm leading-relaxed resize-none focus:outline-none custom-scrollbar
              ${readOnly 
                ? 'text-emerald-300 cursor-text selection:bg-emerald-500/30' 
                : 'text-slate-200 placeholder-slate-600 selection:bg-indigo-500/30'
              }`}
            style={{ lineHeight: '1.5rem' }}
          />
          
          {/* Scan Effect for ReadOnly/Processing state could go here if needed, handled in parent currently */}
        </div>
      </div>
      
      {/* Footer Info */}
      <div className="px-4 py-1.5 bg-[#0A0C14] border-t border-white/5 flex justify-end gap-4 text-[10px] text-slate-500 font-mono">
        <span>Ln {lineCount}, Col 1</span>
        <span>UTF-8</span>
      </div>
    </div>
  );
};