import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center border-b border-white/5 bg-[#05050A]/80 backdrop-blur-md">
      <div className="w-full max-w-[1800px] mx-auto px-6 flex justify-between items-center">
        
        {/* Logo Area */}
        <div className="flex items-center gap-3 group cursor-pointer">
          <div className="relative w-8 h-8 flex items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg shadow-indigo-500/25 group-hover:shadow-indigo-500/40 transition-all duration-300">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            <div className="absolute inset-0 rounded-lg ring-1 ring-inset ring-white/20"></div>
          </div>
          <h1 className="text-lg font-bold tracking-tight text-white">
            Code<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Repair</span>
          </h1>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5 text-xs font-mono text-emerald-400/80">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
            </span>
            System Online
          </div>
          
          <a href="#" className="text-sm text-slate-400 hover:text-white transition-colors font-medium">Documentation</a>
        </div>
      </div>
    </header>
  );
};