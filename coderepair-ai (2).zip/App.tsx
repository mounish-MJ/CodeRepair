import React, { useState } from 'react';
import { Header } from './components/Header';
import { CodeBlock } from './components/CodeBlock';
import { Button } from './components/Button';
import { fixCode } from './services/geminiService';
import { AppStatus, FixedCodeResponse } from './types';

const LANGUAGES = [
  "Auto-Detect", "Python", "JavaScript", "TypeScript", "Java", "C++", "C#", 
  "Go", "Rust", "PHP", "Ruby", "Swift", "Kotlin", "HTML/CSS", "SQL"
];

const SCENARIOS = [
  {
    id: 'recursion',
    label: '⚡ Fix Python Recursion',
    lang: 'Python',
    code: `def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n) 
    # Bug: What happens if I call factorial(-5)?`
  },
  {
    id: 'react-loop',
    label: '⚛️ Debug React Effect',
    lang: 'JavaScript',
    code: `function UserProfile({ id }) {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    fetch('/api/user/' + id).then(u => setUser(u));
    // Bug: Missing dependency array causes infinite loop!
  });

  return <div>{user?.name}</div>;
}`
  },
  {
    id: 'sql-inject',
    label: '🛡️ Patch SQL Injection',
    lang: 'SQL',
    code: `SELECT * FROM users 
WHERE username = ' + userInput + ' 
AND password = ' + passwordInput + ';
-- Bug: This is vulnerable to SQL Injection!`
  }
];

const App: React.FC = () => {
  const [inputCode, setInputCode] = useState<string>('');
  const [selectedLang, setSelectedLang] = useState<string>('Auto-Detect');
  const [result, setResult] = useState<FixedCodeResponse | null>(null);
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);

  const handleFixCode = async () => {
    if (!inputCode.trim()) return;

    setStatus(AppStatus.FIXING);
    setErrorMessage(null);
    setResult(null);

    if (window.innerWidth < 1024) {
      setTimeout(() => {
        document.getElementById('output-panel')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }

    try {
      const hint = selectedLang === 'Auto-Detect' ? undefined : selectedLang;
      const response = await fixCode(inputCode, hint);
      setResult(response);
      setStatus(AppStatus.COMPLETED);
    } catch (error: any) {
      console.error(error);
      setErrorMessage(error.message || "Something went wrong.");
      setStatus(AppStatus.ERROR);
    }
  };

  const simulateTyping = (text: string, lang: string) => {
    setIsTyping(true);
    setInputCode('');
    setResult(null);
    setStatus(AppStatus.IDLE);
    setSelectedLang(lang);

    let i = 0;
    const speed = 10; // ms per char

    const typeChar = () => {
      if (i < text.length) {
        setInputCode(prev => prev + text.charAt(i));
        i++;
        setTimeout(typeChar, speed);
      } else {
        setIsTyping(false);
      }
    };
    typeChar();
  };

  const handleCopy = () => {
    if (result?.fixedCode) {
      navigator.clipboard.writeText(result.fixedCode);
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-10">
      <Header />

      <main className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Intro Section */}
        <div className="text-center py-10 sm:py-16 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
            AI-Powered Code Remediation
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-white mb-6">
            Fix Bugs at the <br className="hidden sm:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">Speed of Thought</span>
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed mb-8">
            Paste your broken code regardless of the language. Our advanced engine will detect errors, fix logic, and explain the solution instantly.
          </p>
          
          {/* Quick Scenarios */}
          <div className="flex flex-wrap justify-center gap-3 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <span className="text-sm text-slate-500 py-2">Try a scenario:</span>
            {SCENARIOS.map(scenario => (
              <button
                key={scenario.id}
                onClick={() => simulateTyping(scenario.code, scenario.lang)}
                disabled={isTyping || status === AppStatus.FIXING}
                className="px-4 py-2 rounded-lg bg-white/5 hover:bg-indigo-500/20 border border-white/10 hover:border-indigo-500/30 text-sm text-slate-300 hover:text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {scenario.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-auto lg:h-[800px]">
          
          {/* Left Panel: Input */}
          <div className="flex flex-col h-[600px] lg:h-full animate-slide-up relative group" style={{ animationDelay: '0.1s' }}>
            
            {/* Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4 px-1">
               <h3 className="text-white font-medium flex items-center gap-2">
                 <div className="w-2 h-6 bg-indigo-500 rounded-sm"></div>
                 Source Code
               </h3>
               <div className="flex items-center gap-3">
                 <select 
                   value={selectedLang}
                   onChange={(e) => setSelectedLang(e.target.value)}
                   className="bg-[#0F111A] text-sm text-slate-300 border border-white/10 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none cursor-pointer hover:bg-white/5 transition-colors"
                 >
                   {LANGUAGES.map(lang => <option key={lang} value={lang}>{lang}</option>)}
                 </select>
               </div>
            </div>

            <div className="relative flex-1 flex flex-col">
              <CodeBlock 
                label="input.code"
                placeholder="// Paste your code here...
// Or click a scenario above to try it out!"
                value={inputCode}
                onChange={setInputCode}
                language={selectedLang === 'Auto-Detect' ? 'Unknown' : selectedLang}
                isTyping={isTyping}
              />
              
              {/* Floating Action Button */}
              <div className="absolute bottom-6 right-6 z-20">
                 <Button 
                   onClick={handleFixCode} 
                   isLoading={status === AppStatus.FIXING || isTyping}
                   disabled={!inputCode.trim() || isTyping}
                   variant="primary"
                   className="shadow-xl shadow-indigo-900/40"
                   icon={
                     <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                     </svg>
                   }
                 >
                   Debug & Fix
                 </Button>
              </div>
            </div>
          </div>

          {/* Right Panel: Output */}
          <div id="output-panel" className="flex flex-col h-[600px] lg:h-full animate-slide-up" style={{ animationDelay: '0.2s' }}>
             
             <div className="flex items-center justify-between mb-4 px-1 h-[42px]">
               <h3 className="text-white font-medium flex items-center gap-2">
                 <div className="w-2 h-6 bg-emerald-500 rounded-sm"></div>
                 Fixed Output
               </h3>
               {status === AppStatus.COMPLETED && (
                 <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
                   Optimized
                 </span>
               )}
             </div>

            {/* Empty State */}
            {status === AppStatus.IDLE && (
               <div className="flex-1 glass-panel rounded-xl border-dashed border-white/10 flex flex-col items-center justify-center text-center p-8">
                 <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-white/5 to-white/0 flex items-center justify-center mb-6 border border-white/5">
                   <svg className="w-10 h-10 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                   </svg>
                 </div>
                 <h4 className="text-slate-300 font-medium text-lg mb-2">Ready to Repair</h4>
                 <p className="text-slate-500 max-w-sm">Waiting for code input. Paste your snippet on the left or choose a scenario.</p>
               </div>
            )}

            {/* Loading State */}
            {status === AppStatus.FIXING && (
               <div className="flex-1 glass-panel rounded-xl relative overflow-hidden flex flex-col items-center justify-center">
                 {/* Scanning line */}
                 <div className="absolute top-0 left-0 w-full h-1 bg-indigo-500 shadow-[0_0_30px_rgba(99,102,241,0.8)] animate-scan z-20"></div>
                 
                 {/* Matrix-like background effect */}
                 <div className="absolute inset-0 opacity-10" style={{ 
                    backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent)',
                    backgroundSize: '50px 50px'
                 }}></div>

                 <div className="relative z-30 text-center">
                    <div className="w-16 h-16 mx-auto mb-6 relative">
                       <div className="absolute inset-0 rounded-full border-t-2 border-indigo-500 animate-spin"></div>
                       <div className="absolute inset-2 rounded-full border-r-2 border-purple-500 animate-spin decoration-slice"></div>
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2 animate-pulse">Analyzing Structure</h3>
                    <div className="flex flex-col gap-1 text-sm text-indigo-300/70 font-mono">
                       <span>Parsing syntax tree...</span>
                       <span>Checking logic patterns...</span>
                    </div>
                 </div>
               </div>
            )}

            {/* Error State */}
            {status === AppStatus.ERROR && (
               <div className="flex-1 glass-panel rounded-xl border-red-500/20 bg-red-900/5 flex flex-col items-center justify-center p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mb-4 border border-red-500/20">
                    <svg className="w-8 h-8 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Analysis Failed</h3>
                  <p className="text-slate-400 max-w-md mb-8">{errorMessage}</p>
                  <Button variant="secondary" onClick={() => setStatus(AppStatus.IDLE)}>
                    Try Again
                  </Button>
               </div>
            )}

            {/* Success State */}
            {status === AppStatus.COMPLETED && result && (
              <div className="flex flex-col h-full gap-4 animate-fade-in">
                <div className="flex-1 relative group">
                  <CodeBlock 
                    label="fixed_output.code"
                    value={result.fixedCode}
                    readOnly
                    language={result.detectedLanguage}
                  />
                  <div className="absolute bottom-6 right-6 z-20">
                    <Button 
                      variant="success"
                      onClick={handleCopy}
                      icon={
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      }
                    >
                      Copy Solution
                    </Button>
                  </div>
                </div>
                
                {/* Explanation Panel */}
                <div className="glass-panel rounded-xl p-6 border-l-4 border-l-emerald-500 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  
                  <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-3">
                       <span className="text-emerald-400 font-mono text-xs uppercase tracking-wider border border-emerald-500/30 px-2 py-0.5 rounded bg-emerald-500/10">
                         Summary
                       </span>
                       <h4 className="text-slate-200 font-semibold">{result.errorSummary}</h4>
                    </div>
                    <p className="text-slate-400 text-sm leading-relaxed">
                      {result.explanation}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;